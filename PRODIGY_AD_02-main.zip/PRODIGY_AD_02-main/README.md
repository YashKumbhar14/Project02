# PRODIGY_AD_02
Create a To-Do list app that allows users to add ,edit and delete tasks.
